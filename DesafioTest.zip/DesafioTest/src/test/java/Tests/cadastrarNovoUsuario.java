package Tests;

import PagesCadastroUsuario.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class cadastrarNovoUsuario {
    private WebDriver navegador;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ufc183.cavalc\\Desktop\\chromer\\chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://seubarriga.wcaquino.me/login");
    }

    @Test
    public void movimentacaoFinanceira() {
        new loginCadastroDeUsuario(navegador)
                .clickLoginCadastroDeUsuario()
                .Cadastro("wellington", "testez22@gmail.com", "123456");

    }
    @After
    public void tearDown() {
        navegador.quit();
    }
}