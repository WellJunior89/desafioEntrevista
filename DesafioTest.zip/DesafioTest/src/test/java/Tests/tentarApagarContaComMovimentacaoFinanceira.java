package Tests;

import PagesTentarApagarContaComMovimetacaoFinanceira.acessarPaginaLogin;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//Para executar esse caso de teste é necessário ter uma conta com movimentação financeira

public class tentarApagarContaComMovimentacaoFinanceira {

    private WebDriver navegador;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ufc183.cavalc\\Desktop\\chromer\\chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://seubarriga.wcaquino.me/login");
    }

    @Test
    public void concaComMovimentacao() {
        new acessarPaginaLogin(navegador)
                .email("teste001@gmail.com")
                .senha("123456")
                .loginRealizado()
                .acessarPaginaConta()
                .tentarApagarConta();
    }

    @After
    public void tearDown() {
        navegador.quit();
    }
}
