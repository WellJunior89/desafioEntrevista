package Tests;

import PagesContaJaCadastrada.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class tentarCriarContaMesmoNome {
    private WebDriver navegador;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ufc183.cavalc\\Desktop\\chromer\\chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://seubarriga.wcaquino.me/login");
    }

    @Test
    public void contaJaCadastrada() {
        new loginContaJaCadastrada(navegador)
                .clickLogin()
                .email("teste001@gmail.com")
                .senha("123456")
                .loginRealizado()
                .acessarPaginaConta()
                .nomeConta("novaConta")
                .erroConta();

    }

    @After
    public void tearDown() {
        navegador.quit();
    }
}
