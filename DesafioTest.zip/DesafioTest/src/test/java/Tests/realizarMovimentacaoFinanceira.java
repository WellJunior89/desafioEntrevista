package Tests;

import PagesMovimentacaoFinanceira.Login;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//Para executar esse caso de teste é necessário ter uma conta já cadastrada

public class realizarMovimentacaoFinanceira {
    private WebDriver navegador;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ufc183.cavalc\\Desktop\\chromer\\chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://seubarriga.wcaquino.me/login");
    }

    @Test
    public void movimentacaoFinanceira() {
        new Login(navegador)
                .clickLogin()
                .email("teste001@gmail.com")
                .senha("123456")
                .loginRealizado()
                .acessarPaginaConta()
                .novaConta("novaConta")
                .criarMovimentacao("01/04/2020", "30/05/2020","teste","Daniel","300")
                .Fim();
    }

    @After
    public void tearDown() {
        navegador.quit();
    }

}