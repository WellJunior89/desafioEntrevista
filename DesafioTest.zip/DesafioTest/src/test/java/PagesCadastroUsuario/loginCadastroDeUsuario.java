package PagesCadastroUsuario;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginCadastroDeUsuario extends BasePage {
    public loginCadastroDeUsuario(WebDriver navegador) {
        super(navegador);
    }

    public cadastroDeUsuario clickLoginCadastroDeUsuario() {
        navegador.findElement(By.xpath("//*[@id=\"bs-example-navbar-collapse-1\"]/ul/li[2]/a")).click();

        return new cadastroDeUsuario(navegador);

    }


}

