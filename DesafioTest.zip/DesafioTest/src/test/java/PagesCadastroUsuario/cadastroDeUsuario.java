package PagesCadastroUsuario;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static org.junit.Assert.assertEquals;

public class cadastroDeUsuario extends BasePage {
    public cadastroDeUsuario(WebDriver navegador) {
        super(navegador);
    }

    public cadastroDeUsuario Cadastro (String nome, String email, String senha){
        navegador.findElement(By.xpath("//*[@id=\"bs-example-navbar-collapse-1\"]/ul/li[2]/a")).click();

        navegador.findElement(By.id("nome")).sendKeys("wellington");
        navegador.findElement(By.id("email")).sendKeys("testez2223@gmail.com");
        navegador.findElement(By.id("senha")).sendKeys("123456");
        navegador.findElement(By.xpath("/html/body/div[2]/form/input")).click();

        WebElement mensagemFinal = navegador.findElement(By.xpath("/html/body/div[1]"));
        String mensagem = mensagemFinal.getText();

        assertEquals("Usuário inserido com sucesso", mensagem);
        return this;
    }
}
