package PagesContaJaCadastrada;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginContaJaCadastrada extends BasePage {
    public loginContaJaCadastrada(WebDriver navegador) {
        super(navegador);
    }


    public contaMesmoNomeLogin clickLogin() {
        navegador.findElement(By.xpath("/html/body/div[2]")).click();
        return new contaMesmoNomeLogin (navegador);
    }
}
