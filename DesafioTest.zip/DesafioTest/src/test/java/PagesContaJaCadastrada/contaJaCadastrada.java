package PagesContaJaCadastrada;
import static org.junit.Assert.*;
import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class contaJaCadastrada extends BasePage {
    public contaJaCadastrada(WebDriver navegador) {
        super(navegador);
    }

    public contaJaCadastrada erroConta (){
        WebElement mensagem = navegador.findElement(By.xpath("/html/body/div[1]"));
                String mensagemFinal = mensagem.getText();

        assertEquals("Já existe uma conta com esse nome!",mensagemFinal);
        return this;
    }
}
