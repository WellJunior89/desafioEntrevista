package PagesContaJaCadastrada;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class contaDuplicada extends BasePage {
    public contaDuplicada(WebDriver navegador) {
        super(navegador);
    }

    public contaJaCadastrada nomeConta(String nome) {

        navegador.findElement(By.id("nome")).sendKeys("novaConta");
        navegador.findElement(By.xpath("/html/body/div[2]/form/div[2]/button")).click();

        return new contaJaCadastrada (navegador);

    }
}