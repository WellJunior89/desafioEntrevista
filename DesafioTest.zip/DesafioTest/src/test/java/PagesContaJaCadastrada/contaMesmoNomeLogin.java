package PagesContaJaCadastrada;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class contaMesmoNomeLogin extends BasePage {
    public contaMesmoNomeLogin(WebDriver navegador) {
        super(navegador);
    }

    public contaMesmoNomeLogin email(String email) {
        navegador.findElement(By.id("email")).sendKeys("teste001@gmail.com");
        return this;
    }

    public contaMesmoNomeLogin senha(String senha) {
        navegador.findElement(By.id("senha")).sendKeys("123456");
        return this;
    }

    public AcessarPaginaContaMesmoNome loginRealizado() {
        navegador.findElement(By.xpath("//div/form/button")).click();
        return new AcessarPaginaContaMesmoNome(navegador);
    }
}
