package PagesContaJaCadastrada;

import BasePages.BasePage;
import PagesMovimentacaoFinanceira.AcessarPaginaConta;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AcessarPaginaContaMesmoNome extends BasePage {
    public AcessarPaginaContaMesmoNome(WebDriver navegador) {
        super(navegador);
    }

    public contaDuplicada acessarPaginaConta(){
        navegador.findElement(By.xpath("//*[@id=\"navbar\"]/ul/li[2]/a")).click();
        navegador.findElement(By.xpath("//*[@id=\"navbar\"]/ul/li[2]/ul/li[1]/a")).click();
        return new contaDuplicada(navegador);
    }
}
