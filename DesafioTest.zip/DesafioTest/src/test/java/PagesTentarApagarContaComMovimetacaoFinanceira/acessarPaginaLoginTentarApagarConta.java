package PagesTentarApagarContaComMovimetacaoFinanceira;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class acessarPaginaLoginTentarApagarConta extends BasePage {
    public acessarPaginaLoginTentarApagarConta(WebDriver navegador) {
        super(navegador);
    }
    public acessarPaginaLogin loginTentarApagarConta() {
        navegador.findElement(By.xpath("//*[@id=\"bs-example-navbar-collapse-1\"]/ul/li[2]/a")).click();

        return new acessarPaginaLogin(navegador);

    }
}
