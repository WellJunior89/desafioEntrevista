package PagesTentarApagarContaComMovimetacaoFinanceira;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class acessarPaginaContaComMovimetacao extends BasePage {
    public acessarPaginaContaComMovimetacao(WebDriver navegador) {
        super(navegador);
    }

    public apagarConta acessarPaginaConta() {
        navegador.findElement(By.xpath("//*[@id=\"navbar\"]/ul/li[2]/a")).click();
        navegador.findElement(By.xpath("//*[@id=\"navbar\"]/ul/li[2]/ul/li[2]/a")).click();
        return new apagarConta(navegador);
    }
}