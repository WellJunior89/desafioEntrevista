package PagesTentarApagarContaComMovimetacaoFinanceira;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class apagarConta extends BasePage {
    public apagarConta(WebDriver navegador) {
        super(navegador);
    }

    public  validarMovimentacaoDuplicada tentarApagarConta() {

        navegador.findElement(By.xpath("//*[@id=\"tabelaContas\"]/tbody/tr/td[2]/a[2]/span")).click();

        return new validarMovimentacaoDuplicada(navegador);
    }
}
