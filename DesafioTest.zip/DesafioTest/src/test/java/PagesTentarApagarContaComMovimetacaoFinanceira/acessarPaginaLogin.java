package PagesTentarApagarContaComMovimetacaoFinanceira;

import BasePages.BasePage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class acessarPaginaLogin extends BasePage {

    public acessarPaginaLogin(WebDriver navegador) {
        super(navegador);
    }

    public acessarPaginaLogin email(String email) {
        navegador.findElement(By.id("email")).sendKeys("teste001@gmail.com");
        return this;
    }

    public acessarPaginaLogin senha(String senha) {
        navegador.findElement(By.id("senha")).sendKeys("123456");
        return this;
    }

    public acessarPaginaContaComMovimetacao loginRealizado() {
        navegador.findElement(By.xpath("//div/form/button")).click();
        return new acessarPaginaContaComMovimetacao(navegador);
    }
}
