package PagesTentarApagarContaComMovimetacaoFinanceira;
import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static org.junit.Assert.assertEquals;

public class validarMovimentacaoEmUso extends BasePage {
    public validarMovimentacaoEmUso(WebDriver navegador) {
        super(navegador);
    }

    public void mensagemDeErro(){
        WebElement mensagem = navegador.findElement(By.xpath("/html/body/div[1]"));
        String mensagemDeErro = mensagem.getText();

         assertEquals("Conta em uso movimetações",mensagemDeErro);
    }
}
