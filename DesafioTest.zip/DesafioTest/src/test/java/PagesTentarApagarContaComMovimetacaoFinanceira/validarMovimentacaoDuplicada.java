package PagesTentarApagarContaComMovimetacaoFinanceira;
import static org.junit.Assert.*;
import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class validarMovimentacaoDuplicada extends BasePage {
    public validarMovimentacaoDuplicada(WebDriver navegador) {
        super(navegador);
    }

    public void mensagemDeErro(){
        WebElement mensagem = navegador.findElement(By.xpath("/html/body/div[1]"));
        String mensagemDeErro = mensagem.getText();

         assertEquals("Conta em uso movimetações",mensagemDeErro);
    }
}
