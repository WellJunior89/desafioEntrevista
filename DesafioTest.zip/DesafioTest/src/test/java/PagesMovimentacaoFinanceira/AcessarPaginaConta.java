package PagesMovimentacaoFinanceira;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AcessarPaginaConta extends BasePage {
    public AcessarPaginaConta(WebDriver navegador) {
        super(navegador);
    }

    public novaConta acessarPaginaConta(){
    navegador.findElement(By.xpath("//*[@id=\"navbar\"]/ul/li[2]/a")).click();
    navegador.findElement(By.xpath("//*[@id=\"navbar\"]/ul/li[2]/ul/li[1]/a")).click();
    return new novaConta(navegador);
    }
}
