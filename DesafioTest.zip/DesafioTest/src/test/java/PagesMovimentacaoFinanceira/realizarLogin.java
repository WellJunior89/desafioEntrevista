package PagesMovimentacaoFinanceira;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static org.junit.Assert.assertEquals;

public class realizarLogin extends BasePage {
    public realizarLogin(WebDriver navegador) {
        super(navegador);
    }

    public realizarLogin email(String email) {
        navegador.findElement(By.id("email")).sendKeys("teste001@gmail.com");
        return this;
    }

    public realizarLogin senha(String senha) {
        navegador.findElement(By.id("senha")).sendKeys("123456");
        return this;
    }

    public AcessarPaginaConta loginRealizado() {
        navegador.findElement(By.xpath("//div/form/button")).click();
        return new AcessarPaginaConta(navegador);
    }


}


