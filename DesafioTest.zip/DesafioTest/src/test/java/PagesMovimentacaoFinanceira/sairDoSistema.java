package PagesMovimentacaoFinanceira;

import static org.junit.Assert.*;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class sairDoSistema extends BasePage {
    public sairDoSistema(WebDriver navegador) {
        super(navegador);
    }
    public sairDoSistema Fim(){

        WebElement testeFinal = navegador.findElement(By.xpath("/html/body/nav/div/div[1]/a"));
        String mensagemFinal = testeFinal.getText();

        assertEquals("Seu Barriga", mensagemFinal);
        return this;
    }
}
