package PagesMovimentacaoFinanceira;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class criarMovimentacao extends BasePage {
    public criarMovimentacao(WebDriver navegador) {
        super(navegador);
    }

    public sairDoSistema criarMovimentacao(String data_transacao, String data_pagamento, String descricao, String interessado, String valor){

        navegador.findElement(By.xpath("//*[@id=\"navbar\"]/ul/li[3]/a")).click();

        WebElement tipoDeMovimentação = navegador.findElement(By.name("tipo"));
        new Select(tipoDeMovimentação).selectByVisibleText("Receita");

        navegador.findElement(By.id("data_transacao")).sendKeys("01/04/2020");
        navegador.findElement(By.id("data_pagamento")).sendKeys("30/05/2020");
        navegador.findElement(By.id("descricao")).sendKeys("teste");
        navegador.findElement(By.id("interessado")).sendKeys("Daniel");
        navegador.findElement(By.id("valor")).sendKeys("300");
        navegador.findElement(By.id("conta")).click();

        WebElement tipoDeConta = navegador.findElement(By.name("conta"));
        new Select(tipoDeConta).selectByVisibleText("novaConta");

        navegador.findElement(By.id("status_pendente")).click();

        navegador.findElement(By.xpath("/html/body/div[2]/form/div[4]/button")).click();

        return new sairDoSistema(navegador);
    }
}
