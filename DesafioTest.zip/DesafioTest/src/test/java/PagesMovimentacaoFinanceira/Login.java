package PagesMovimentacaoFinanceira;

import BasePages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login extends BasePage {
    public Login(WebDriver navegador) {
        super(navegador);
    }

    public realizarLogin clickLogin() {
        navegador.findElement(By.xpath("/html/body/div[2]")).click();

        return new realizarLogin(navegador);
    }
}
